#!/usr/bin/env python3
import sys

# Mapper reads from stdin
for line in sys.stdin:
    # Strip any extra whitespace and split the line
    line = line.strip()
    words = line.split()

    # Output each word as a key with a count of 1
    for word in words:
        print(f"{word}\t1")
